
import React from 'react'

export default function App(){
  return (
    <div style={{padding:20, fontSize:20}}>
      <h1>Mkheeng — Website Live</h1>
      <p>This is your starter React site. I can expand it anytime.</p>
    </div>
  )
}
